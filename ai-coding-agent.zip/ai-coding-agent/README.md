# AI Coding Agent

A minimal full-stack coding agent: a React/TypeScript chat UI talks to an Express/WebSocket
backend that runs a Groq tool-use loop, writes files into a sandboxed `workspace/`
directory, and shows the result in a live preview iframe that auto-refreshes on every edit.

```
ai-coding-agent/
├── server/          Express + WebSocket backend, agent loop, workspace sandbox
│   ├── src/
│   │   ├── index.ts       Server entrypoint (HTTP + WS + static preview)
│   │   ├── agentLoop.ts   Groq tool-use loop
│   │   ├── tools.ts       write_file / read_file / list_files / delete_file
│   │   └── types.ts       Event + message types
│   ├── workspace/         Where the agent's generated project lives (served at /preview)
│   └── render.yaml        Render deployment blueprint
└── client/          React + Vite + TypeScript frontend
    └── src/
        ├── App.tsx             Chat panel + live preview panel
        ├── config.ts           Resolves backend URL (dev proxy vs deployed)
        ├── hooks/useAgentWebSocket.ts
        ├── services/websocket.ts
        ├── components/         ChatMessage, SuggestionButtons, ConnectionStatus, LivePreview
        └── types/agent.types.ts
```

## 1. Get a Groq API key

Free at https://console.groq.com/ — create an account, then generate a key under API Keys.

## 2. Run it locally (Termux, or any machine with Node)

```bash
pkg install nodejs git   # Termux only — skip on a normal PC
```

**Terminal 1 — backend:**
```bash
cd server
npm install
cp .env.example .env
# edit .env and paste your GROQ_API_KEY (nano .env)
npm run dev
```

**Terminal 2 — frontend:**
```bash
cd client
npm install
npm run dev
```

Open the URL Vite prints (typically `http://localhost:5173`). In dev, Vite's proxy forwards
`/ws` and `/preview` to the backend on port 3001, so you only ever open one URL.

Type a request like:

> Build a simple landing page with a hero section, three feature cards, and a contact form.

## 3. Deploy it for real (so anyone can use it, without your phone staying on)

This app has two halves that deploy separately: the **backend** (runs the agent, needs your
API key) and the **frontend** (static site, talks to the backend over the internet).

### Backend → Render

1. Push this project to a GitHub repo.
2. On https://render.com, click **New → Blueprint**, point it at your repo. It will read
   `server/render.yaml` automatically. (If you'd rather set it up manually: root directory
   `server`, build command `npm install && npm run build`, start command `npm start`.)
3. In the Render dashboard, add the environment variable `GROQ_API_KEY` with your key.
4. Deploy. You'll get a URL like `https://ai-coding-agent-server.onrender.com`.

**Note:** Render's free tier has an ephemeral filesystem — the `workspace/` folder (and
anything the agent builds) is wiped on every redeploy or restart. That's fine for a live
demo tool where each visitor asks the agent to build something fresh, but don't rely on it
to permanently store anyone's generated project.

### Frontend → Vercel

1. On https://vercel.com, **New Project**, import the same repo, set root directory to
   `client`. Vercel auto-detects Vite.
2. Add an environment variable: `VITE_BACKEND_URL` = your Render URL from above
   (e.g. `https://ai-coding-agent-server.onrender.com`).
3. Deploy. Vercel gives you a public URL — that's the link you share with "everyone."

From here on, updating the app is: edit code → `git push` → both Render and Vercel
auto-redeploy.

## How it works

- **Backend (`agentLoop.ts`)** calls Groq's chat completions API (OpenAI-compatible) with
  `write_file`, `read_file`, `list_files`, and `delete_file` tools. It loops — feeding tool
  results back to the model — until the model responds without requesting another tool call,
  then emits a `finished` event.
- **Sandbox (`tools.ts`)** resolves every path against `server/workspace/` and rejects
  anything that would escape it (absolute paths, `../` traversal), so the model can't touch
  files outside the project directory.
- **Live preview** is `express.static` serving `server/workspace/` at `/preview`, with
  `Cache-Control: no-store` so edits are never served stale. The frontend's `<iframe>`
  remounts (via a `key` that increments on every `file_changed` event) to force a fresh load.
- **Reconnect logic** in `services/websocket.ts` uses exponential backoff, so a dropped
  connection (e.g. backend cold-starting on Render's free tier) recovers on its own.

## Known limitations / things to extend

- Conversation history is kept in memory per WebSocket connection — a backend restart or
  page refresh loses it. Persist `history` somewhere (SQLite, Redis) for durability.
- Only one shared workspace exists — every visitor to your deployed app edits the *same*
  project. Fine for a single-user demo; for real multi-user use you'd need to key the
  workspace and history per session/connection.
- Public + no auth means anyone with the link can drive the agent and rack up Groq usage on
  your key. Consider adding a simple auth check or rate limit before sharing the link widely.
- No `run_command` tool — the agent can only write static HTML/CSS/JS, no package installs
  or build steps. That's intentional: letting an LLM run arbitrary shell commands is a much
  bigger trust boundary and needs real sandboxing (isolated container, no network, time/CPU
  limits) before it's safe to add.
- If `npm install` in `server/` complains about the `groq-sdk` version, run
  `npm install groq-sdk@latest` — the SDK updates fairly often.
