import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { createServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import fs from 'fs/promises';
import { runAgent } from './agentLoop';
import { WORKSPACE_DIR } from './tools';
import type { AgentEvent, ClientMessage } from './types';

async function main() {
  await fs.mkdir(WORKSPACE_DIR, { recursive: true });

  const app = express();
  // Frontend and backend live on different domains once deployed (e.g. Vercel + Render),
  // so /health and /preview need CORS. WebSocket connections aren't subject to CORS.
  app.use(cors());
  const server = createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  // Serves the agent's generated project so the frontend can show it live in an iframe.
  // Cache-Control: no-store keeps the preview from going stale after each edit.
  app.use(
    '/preview',
    express.static(WORKSPACE_DIR, {
      etag: false,
      lastModified: false,
      setHeaders: (res) => res.setHeader('Cache-Control', 'no-store'),
    })
  );

  app.get('/health', (_req, res) => res.json({ ok: true }));

  wss.on('connection', (ws: WebSocket) => {
    let history: { role: 'user' | 'assistant'; content: any }[] = [];

    const emit = (event: AgentEvent) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(event));
      }
    };

    ws.on('message', async (raw) => {
      let msg: ClientMessage;
      try {
        msg = JSON.parse(raw.toString());
      } catch {
        emit({ type: 'error', content: 'Invalid message format' });
        return;
      }

      if (msg.type === 'reset') {
        history = [];
        return;
      }

      if (msg.type === 'user_message') {
        if (!process.env.GROQ_API_KEY) {
          emit({
            type: 'error',
            content: 'Server is missing GROQ_API_KEY. Add it to server/.env and restart the server.',
          });
          return;
        }
        history = await runAgent(msg.content, history, emit);
      }
    });

    ws.on('error', (err) => console.error('WebSocket error:', err));
  });

  const PORT = Number(process.env.PORT) || 3001;
  server.listen(PORT, () => {
    console.log(`Agent server listening on http://localhost:${PORT}`);
    console.log(`WebSocket endpoint:      ws://localhost:${PORT}/ws`);
    console.log(`Live preview:            http://localhost:${PORT}/preview/`);
  });
}

main().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
