import fs from 'fs/promises';
import path from 'path';
import type { AgentEvent } from './types';

export const WORKSPACE_DIR = path.resolve(__dirname, '../workspace');

// Prevents the model from writing/reading outside the workspace directory
// (blocks both absolute paths and "../../" traversal).
function resolveSafe(relativePath: string): string {
  const resolved = path.resolve(WORKSPACE_DIR, relativePath);
  if (resolved !== WORKSPACE_DIR && !resolved.startsWith(WORKSPACE_DIR + path.sep)) {
    throw new Error(`Refusing to access path outside the workspace: ${relativePath}`);
  }
  return resolved;
}

// Groq's API is OpenAI-compatible, which wraps each tool in { type: "function", function: {...} }
// rather than the flatter shape Anthropic uses.
export const TOOL_DEFINITIONS = [
  {
    type: 'function',
    function: {
      name: 'write_file',
      description:
        'Create or overwrite a file in the workspace. Creates parent directories automatically. ' +
        'Use this for every file you want to add to the project (HTML, CSS, JS, etc.).',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'Relative path within the workspace, e.g. "index.html" or "styles/main.css"' },
          content: { type: 'string', description: 'The full contents of the file' },
        },
        required: ['path', 'content'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'read_file',
      description: 'Read the current contents of a file in the workspace.',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'Relative path within the workspace' },
        },
        required: ['path'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'list_files',
      description: 'List every file currently in the workspace, recursively.',
      parameters: {
        type: 'object',
        properties: {},
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'delete_file',
      description: 'Delete a file from the workspace.',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'Relative path within the workspace' },
        },
        required: ['path'],
      },
    },
  },
] as const;

async function walk(dir: string, base: string): Promise<string[]> {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const files: string[] = [];
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...(await walk(full, base)));
    } else {
      files.push(path.relative(base, full));
    }
  }
  return files;
}

export async function executeTool(
  name: string,
  input: Record<string, unknown>,
  emit: (event: AgentEvent) => void
): Promise<string> {
  switch (name) {
    case 'write_file': {
      const relPath = String(input.path ?? '');
      const content = String(input.content ?? '');
      if (!relPath) throw new Error('write_file requires a "path"');
      const target = resolveSafe(relPath);
      await fs.mkdir(path.dirname(target), { recursive: true });
      await fs.writeFile(target, content, 'utf-8');
      emit({ type: 'file_changed', path: relPath });
      return `Wrote ${content.length} bytes to ${relPath}`;
    }

    case 'read_file': {
      const relPath = String(input.path ?? '');
      if (!relPath) throw new Error('read_file requires a "path"');
      const target = resolveSafe(relPath);
      return await fs.readFile(target, 'utf-8');
    }

    case 'list_files': {
      await fs.mkdir(WORKSPACE_DIR, { recursive: true });
      const files = await walk(WORKSPACE_DIR, WORKSPACE_DIR);
      return files.length ? files.join('\n') : '(workspace is currently empty)';
    }

    case 'delete_file': {
      const relPath = String(input.path ?? '');
      if (!relPath) throw new Error('delete_file requires a "path"');
      const target = resolveSafe(relPath);
      await fs.unlink(target);
      emit({ type: 'file_changed', path: relPath });
      return `Deleted ${relPath}`;
    }

    default:
      throw new Error(`Unknown tool: ${name}`);
  }
}
