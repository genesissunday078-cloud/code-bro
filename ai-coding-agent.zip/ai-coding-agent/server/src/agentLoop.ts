import Groq from 'groq-sdk';
import { executeTool, TOOL_DEFINITIONS } from './tools';
import type { AgentEvent } from './types';

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

// Any current Groq model that supports tool use works here. Swap if you want a
// different speed/quality tradeoff: https://console.groq.com/docs/models
const MODEL = 'llama-3.3-70b-versatile';
const MAX_TURNS = 12;

const SYSTEM_PROMPT = `You are a coding agent that builds small static web projects (HTML, CSS, and vanilla JS) inside a sandboxed workspace directory.

Rules:
- Always use the provided tools (write_file, read_file, list_files, delete_file) to make changes. Never just describe changes in text -- actually write the files.
- The project is live-previewed from workspace/index.html, so make sure that file exists and correctly links any CSS/JS files you create.
- Prefer small, focused edits. Use read_file before editing a file you didn't just write, so you don't clobber existing content by accident.
- Keep prose brief. Prefer taking action over describing what you're about to do.
- When a request is complete, give the user a short (1-3 sentence) summary of what you built or changed.`;

// Groq's SDK types shift across versions, so message history is typed loosely here
// and validated by shape at runtime, same approach used for the Anthropic SDK before.
type AgentMessage = Record<string, any>;

export async function runAgent(
  userMessage: string,
  history: AgentMessage[],
  emit: (event: AgentEvent) => void
): Promise<AgentMessage[]> {
  const messages: AgentMessage[] = [...history, { role: 'user', content: userMessage }];
  const startedAt = Date.now();

  for (let turn = 0; turn < MAX_TURNS; turn++) {
    let response;
    try {
      response = await groq.chat.completions.create({
        model: MODEL,
        max_tokens: 4096,
        messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...messages] as any,
        tools: TOOL_DEFINITIONS as any,
        tool_choice: 'auto',
      });
    } catch (err: any) {
      emit({ type: 'error', content: `LLM request failed: ${err?.message ?? String(err)}` });
      return messages;
    }

    const message = response.choices?.[0]?.message;
    if (!message) {
      emit({ type: 'error', content: 'Empty response from Groq.' });
      return messages;
    }

    const toolCalls: any[] = message.tool_calls ?? [];

    if (message.content && message.content.trim()) {
      emit({ type: toolCalls.length > 0 ? 'thought' : 'done', content: message.content });
    }

    messages.push({
      role: 'assistant',
      content: message.content ?? '',
      ...(toolCalls.length > 0 ? { tool_calls: toolCalls } : {}),
    });

    if (toolCalls.length === 0) {
      const worked_for = Math.round((Date.now() - startedAt) / 1000);
      emit({ type: 'finished', worked_for });
      return messages;
    }

    for (const toolCall of toolCalls) {
      const toolName = toolCall.function?.name ?? 'unknown';
      let args: Record<string, unknown> = {};
      try {
        args = toolCall.function?.arguments ? JSON.parse(toolCall.function.arguments) : {};
      } catch {
        args = {};
      }

      emit({ type: 'tool_call', id: toolCall.id, tool_name: toolName, arguments: args });

      let resultContent: string;
      try {
        resultContent = await executeTool(toolName, args, emit);
        emit({ type: 'tool_result', id: toolCall.id, tool_name: toolName, result: resultContent });
      } catch (err: any) {
        resultContent = err?.message ?? String(err);
        emit({ type: 'tool_result', id: toolCall.id, tool_name: toolName, result: resultContent, error: true });
      }

      messages.push({ role: 'tool', tool_call_id: toolCall.id, content: resultContent });
    }
  }

  emit({ type: 'error', content: 'Stopped after reaching the maximum number of turns for this request.' });
  return messages;
}
