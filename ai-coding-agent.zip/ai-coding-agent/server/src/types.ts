export type Suggestion = {
  title: string;
  description: string;
  prompt: string;
};

// Events streamed from server -> client over the WebSocket.
export type AgentEvent =
  | { type: 'thought'; content: string }
  | { type: 'tool_call'; id: string; tool_name: string; arguments: Record<string, unknown> }
  | { type: 'tool_result'; id: string; tool_name: string; result: string; error?: boolean }
  | { type: 'file_changed'; path: string }
  | { type: 'done'; content: string }
  | { type: 'suggestions'; suggestions: Suggestion[] }
  | { type: 'finished'; worked_for: number }
  | { type: 'error'; content: string };

// Messages sent from client -> server over the WebSocket.
export type ClientMessage =
  | { type: 'user_message'; content: string }
  | { type: 'reset' };
